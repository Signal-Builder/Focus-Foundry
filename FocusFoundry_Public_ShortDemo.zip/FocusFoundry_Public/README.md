# Focus Foundry — Public Demo

Cinematic landing page demo built with modular HTML, CSS, and JavaScript. Deploy on **GitHub Pages, Netlify, Vercel, Cloudflare Pages, or any static host**.

> This repo is a **showcase**. For custom builds, premium effects, and full funnel stacks, hire me or request a license.

## Live Demo
- (Add your link once deployed)

## Use
- Open `index.html` to preview locally.
- Edit `css/style.css` and `js/script.js` to customize.
- Deploy by dragging these files to any static host.

## Hire / License
- Fiverr: (link)
- Upwork: (link)
- Email: you@domain.com

---
© 2025 Briteminds · Updated Aug 24, 2025
